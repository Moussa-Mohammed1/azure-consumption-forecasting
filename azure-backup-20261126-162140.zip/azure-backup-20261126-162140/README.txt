Sauvegarde Azure — abonnement "formation-devops-simplon" — 20261126-162140 (UTC)
Resource groups : moussa-mohammed

Contenu (par resource group) :
  arm-template.json        template ARM du resource group
  resources/               configuration JSON de chaque ressource
  datafactory/<factory>/   linked services, datasets, pipelines, data flows, triggers
  storage/<compte>/data/   tous les fichiers des containers (arborescence conservée)
  storage/<compte>/fileshares/  contenu des partages Azure Files

Restaurer :
  - Ressources   : portail > "Deploy a custom template" > arm-template.json
  - Data Factory : recréer la factory, puis pour chaque JSON :
      az datafactory linked-service create -g RG --factory-name F -n NOM --properties @<json>.properties
      az datafactory dataset create        ... --properties @...
      az datafactory pipeline create       ... --pipeline   @...
    (les clés/secrets ne sont jamais exportés : re-sélectionner le compte dans les linked services)
  - Données      : ré-uploader storage/<compte>/data/<container> via Storage browser ou azcopy
